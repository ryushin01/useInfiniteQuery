export const API_baseURL = "https://pokeapi.co/api/v2/"
export const API_IMG_baseURL = "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/dream-world"
